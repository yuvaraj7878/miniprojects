import React, { useState } from 'react';
import {
  Box, Button, TextField, Typography,
  Stepper, Step, StepLabel, Paper
} from '@mui/material';
import { Upload as UploadIcon } from '@mui/icons-material';

const steps = ['Basic Information', 'Upload Documents', 'Review & Submit'];

const ApplicationForm = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    licenseType: 'New',
    documents: []
  });


  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = (e) => {
    const files = Array.from(e.target.files);
    setFormData(prev => ({
      ...prev,
      documents: [...prev.documents, ...files.map(file => file.name)]
    }));
  };

  const handleSubmit = () => {
    // In a real app, you would send this to your backend
    alert(`Application submitted successfully!`);
    console.log('Submitted:', formData);
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 3 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      
      {activeStep === 0 && (
        <Box component="form">
          <Typography variant="h6" gutterBottom>
            Basic Information
          </Typography>
          <TextField
            label="Full Name"
            name="name"
            fullWidth
            required
            value={formData.name}
            onChange={handleChange}
            sx={{ mb: 2 }}
          />
          <TextField
            label="Email"
            type="email"
            name="email"
            fullWidth
            required
            value={formData.email}
            onChange={handleChange}
            sx={{ mb: 2 }}
          />
          <TextField
            label="Phone Number"
            name="phone"
            fullWidth
            required
            value={formData.phone}
            onChange={handleChange}
            sx={{ mb: 2 }}
          />
          <TextField
            label="Address"
            name="address"
            fullWidth
            required
            multiline
            rows={3}
            value={formData.address}
            onChange={handleChange}
            sx={{ mb: 2 }}
          />
        </Box>
      )}
      
      {activeStep === 1 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Upload Required Documents
          </Typography>
          <input
            accept=".pdf,.jpg,.png"
            style={{ display: 'none' }}
            id="raised-button-file"
            multiple
            type="file"
            onChange={handleFileUpload}
          />
          <label htmlFor="raised-button-file">
            <Button 
              variant="contained" 
              component="span"
              startIcon={<UploadIcon />}
              sx={{ mb: 2 }}
            >
              Upload Documents
            </Button>
          </label>
          {formData.documents.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2">Uploaded Documents:</Typography>
              <ul>
                {formData.documents.map((doc, index) => (
                  <li key={index}>{doc}</li>
                ))}
              </ul>
            </Box>
          )}
        </Box>
      )}
      
      {activeStep === 2 && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Review Your Application
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Name:</strong> {formData.name}
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Email:</strong> {formData.email}
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Phone:</strong> {formData.phone}
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Address:</strong> {formData.address}
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Documents:</strong> {formData.documents.join(', ')}
          </Typography>
        </Box>
      )}
      
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
        {activeStep !== 0 && (
          <Button onClick={handleBack} sx={{ mr: 1 }}>
            Back
          </Button>
        )}
        {activeStep === steps.length - 1 ? (
          <Button variant="contained" onClick={handleSubmit}>
            Submit Application
          </Button>
        ) : (
          <Button variant="contained" onClick={handleNext}>
            Next
          </Button>
        )}
      </Box>
    </Paper>
  );
};

export default ApplicationForm;